phone.receive(function(session){

    // On Call Receiving

});
