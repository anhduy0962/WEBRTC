var localVideoElem = null, remoteVideoElem = null, localVideoStream = null,



    videoCallButton = null, endCallButton = null,



    peerConn = null, wsc = new WebSocket('ws://radium.informatik.tu-cottbus.de/websocket/'),



    peerConnCfg = {'iceServers': 



      [{'url': 'stun:stun.services.mozilla.com'}, {'url': 'stun:stun.l.google.com:19302'}]



    };



/** browser dependent definition are aligned to one and the same standard name **/



navigator.getUserMedia = navigator.getUserMedia || navigator.mozGetUserMedia || navigator.webkitGetUserMedia;



window.RTCPeerConnection = window.RTCPeerConnection || window.mozRTCPeerConnection || window.webkitRTCPeerConnection;



window.RTCIceCandidate = window.RTCIceCandidate || window.mozRTCIceCandidate || window.webkitRTCIceCandidate;



window.RTCSessionDescription = window.RTCSessionDescription || window.mozRTCSessionDescription || window.webkitRTCSessionDescription;



window.SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition || window.mozSpeechRecognition 



  || window.msSpeechRecognition || window.oSpeechRecognition;







var config = {



  wssHost: 'wss://wotpal.club'



  // wssHost: 'wss://example.com/myWebSocket'



};



var localVideoElem = null, 



  remoteVideoElem = null, 



  localVideoStream = null,



  videoCallButton = null, 



  endCallButton = null;



var peerConn = null,



  wsc = new WebSocket(config.wssHost),



  peerConnCfg = {'iceServers': 



    [{'url': 'stun:stun.services.mozilla.com'}, 



     {'url': 'stun:stun.l.google.com:19302'}]



  };







function pageReady() {



  // check browser WebRTC availability 
 
 
@@ -55,15 +72,17 @@ function answerCall() {







wsc.onmessage = function (evt) {



  var signal = null;



  if (!peerConn)



    answerCall();



  if (!peerConn) answerCall();



  signal = JSON.parse(evt.data);



  if (signal.sdp) {



    console.log("Received SDP from remote peer.");



    peerConn.setRemoteDescription(new RTCSessionDescription(signal.sdp));



  }



  else if (signal.candidate) {



    console.log("Received ICECandidate from remote peer.");



    peerConn.addIceCandidate(new RTCIceCandidate(signal.candidate));



  } else if ( signal.closeConnection){



    console.log("Received 'close call' signal from remote peer.");



    endCall();



  }



};
 
@@ -76,14 +95,10 @@ function createAndSendOffer() {



        function() {



          wsc.send(JSON.stringify({"sdp": off }));



        }, 



        function(error) { 



          console.log(error);



        }



        function(error) { console.log(error);}



      );



    }, 



    function (error) { 



      console.log(error);



    }



    function (error) { console.log(error);}



  );



};




 
@@ -94,14 +109,10 @@ function createAndSendAnswer() {



      peerConn.setLocalDescription(ans, function() {



          wsc.send(JSON.stringify({"sdp": ans }));



        }, 



        function (error) { 



          console.log(error);



        }



        function (error) { console.log(error);}



      );



    },



    function (error) { 



      console.log(error);



    }



    function (error) {console.log(error);}



  );



};




 
@@ -122,9 +133,11 @@ function endCall() {



  peerConn = null;



  videoCallButton.removeAttribute("disabled");



  endCallButton.setAttribute("disabled", true);



  localVideoStream.getTracks().forEach(function (track) {



    track.stop();



  });



  localVideo.src = "";



  remoteVideo.src = "";



};



  if (localVideoStream) {



    localVideoStream.getTracks().forEach(function (track) {



      track.stop();



    });



    localVideo.src = "";



  }



  if (remoteVideo) remoteVideo.src = "";



};
