phone.receive(function(session){

    session.connected(function(session){

        // Append Live Video and Voice Feed

        $('#display-div').append(session.video);

    });

});
